---
title: Guide ▲ Advanced - VLOOK™ - Elegant and Practical Typora Theme & Plugin
author: MAX°孟兆
description: Regarding VLOOK™: Text, Paragraphs, Tables, Images, Lists, and Section Headings
"og:description": Regarding VLOOK™: Text, Paragraphs, Tables, Images, Lists, and Section Headings
"og:image": https://vlook-doc.pages.dev/pic/vlook-og.png
keywords:
- gitee,github,i18n,markdown,mit,osc,plugin,typora,vlook,github style alert,ogp,open graph protocol,mermaid,wiki,html,prd,yaml,youtube
- editor's recommendation,plugin,open source,oschina (open source china),cross-platform,theme,font style,automatic typesetting,tag,multi-level tag,rainbow color,outline,code block,alignment,multimedia,back cover,front cover,formula,scratch card,black curtain,badge,gradient color,footnote,progress bar,breadcrumb,template,task list,color code,social network sharing,video,customization,caption,audio,coloring,theme,phonetic notation,automatic numbering,automatic folding,word count,font
- light mode,dark mode,grayscale mode,gray mode,publish as pdf,export as pdf,card-style link,link card
- catalogue,library,illustration navigation,outline navigation,paragraph navigation,footnote navigation,picture navigation,library navigation,chapter navigation,navigation history,table index,picture index,audio index,video index,code block index,search,word segmentation
- table cross cursor,table reading mode,table enhancement,table note,repeated table header,numerical format,cell merging,currency format,row grouping,row folding,percentage format
- picture browsing,picture layout,picture silhouette,picture zooming,picture enhancement,picture note,high-definition screen,high-definition picture,inversion,negative color,postcard,picture filter,horizontal flip of picture,vertical flip of picture,picture rotation,mixed arrangement of pictures and text
- online video,streaming media,bilibili video,watermelon video,douyin video,tencent video
- content assistant,publishing assistance,presentation assistance,copy,laser pointer,spotlight,picture-in-picture,publish as pdf,export as pdf,save as pdf,print to pdf
- text color,paragraph layout,button,button link,primary button,secondary button,super button, tab group,columns,two columns,three columns,four columns,five columns,quote block,title,details,summary,subtitle,official account article,official account editor
- link map,link specification,link check,link recognition,link conversion
- design,requirement,document,blog,manual,guide,knowledge base,tutorial,scheme,education,note,diary
- product manager,programmer,operation and maintenance,pre-sales,after-sales,trainer,teacher,student,engineer,lawyer
- 编辑推荐,插件,开源,开源中国,跨平台,主题,字体风格,自动排版,标签,多级标签,彩虹色,大纲,代码块,对齐方式,多媒体,封底,封面,公式,刮刮卡,黑幕,徽章,渐变色,脚注,进度条,面包屑,模板,任务清单,色号,社交网络分享,视频,定制,题注,音频,着色,主题,注音,自动编号,自动折叠,字数统计,字体
- 浅色外观,深色外观,灰度外观,灰色外观,发布为PDF,导出为PDF,卡片式链接,链接卡片
- 目录,文库,插图导航,大纲导航,段落漫游,脚注导航,图片导航,文库导航,章节导航,导航历史,表格索引,图片索引,音频索引,视频索引,代码块索引,搜索,分词
- 表格十字光标,表格阅读模式,表格增强,表注,数值格式,单元格合并,货币格式,行分组,行折叠,百分比格式
- 图片浏览,图片版式,图片剪影,图片缩放,图片增强,图注,高清屏,高清图,反转,反色,明信片,图片滤镜,图片水平翻转,图片垂直翻转,图片旋转,图文混排
- 在线视频,流媒体,B站视频,西瓜视频,抖音视频,腾讯视频
- 内容助手,出版辅助,演示辅助,复制,激光笔,聚光灯,画中画,发布为PDF,导出为PDF,另存为PDF,打印为PDF
- 文本颜色,段落排版,按钮,按钮链接,主按钮,次按钮,超级按钮,页签组,分栏,双栏,三栏,四栏,五栏,引用块,标题,小标题,折叠,公众号文章,公众号编辑器
- 链接地图,链接规范,链接检查,链接识别,链接转换
- 设计,需求,文档,博客,手册,指南,攻略,知识库,教程,方案,教育,笔记,日记
- 产品经理,程序员,运维,售前,售后,培训师,老师,学生,工程师,律师
vlook-header-dup: /^Your coffee.+/;/.*Syntax$/;/^Applicable Scope ••• .+/;Shortcuts;Advanced Usage;More Information;Blockquote Coloring;COMMING SOON...;Image with Line Grid Background;Image with Block Grid Background;Examples;This is a Blockquote Subtitle;💡 Want to know the original content of the above table?
vlook-doc-lib:
- [How to Start?](index-en.html?target=_self "Introduction, Installation and Configuration, Language Packs")
- [Guide • Basic](guide-en.html?target=_self "Text Color / Gradient, Paragraph Formatting / Bold / Underline / Highlight, Table Cell Merging / Column Formatting / Coloring / Row Grouping & Collapsing / Wrapping / Color, Image Layout / Scale / Rotation / Flip / Filter / Postcard / Silhouette / High-Definition, Lists / Task Lists, Blockquote Subtitles / Collapsible / Color, Section Title Auto-Numbering, …")
- [Guide ▲ Advanced](guide2-en.html?target=_self "Columns, Captions, Buttons, Code / Copy / Wrap, Cover / Back Cover, Tab Groups, Github-Style Alerts, Tag / Badge, Progress Bar, Breadcrumb, Scratch Card, Phonetic Annotations, Mermaid, Math Formula, Multimedia / Audio / Video / Streaming, …")
- [Guide ★ Exploration](guide3-en.html?target=_self "Content Navigation / History / Last Read, Content Assistant / Copy / Fullscreen / Wrap / Crosshair / Reading Mode / Picture-In-Picture, Presentation Aids / Laser Pointer / Spotlight / Paragraph Roaming / Width Fit, Publishing Aids / Mark As Unpublished / Social Sharing / Publish as PDF / Export as PDF / Save as PDF / Print to PDF / Link Map / Long Content Folding / Link Checker / Link Recognition, Appearance / Themes / Fonts / Light / Dark, Custom / Preset Options / Tuning Parameters, Keyboard Shortcuts, …")
- [Value-added Services](vip-en.html?target=_self "Custom Themes, Document Typesetting and Editing,...")
- [More Content](vlook-lib-en.html "VLOOK™ Full Feature Index Table")
- [Report Issues](https://github.com/MadMaxChow/VLOOK/issues?target=issues "GitHub Issues")
---

[TOC]

> Select language ❯ *[<kbd>🇨🇳 简体中文</kbd>](guide.md)*

# ==Some Conventions==

## #Magic

==*`#Magic`*_~CyOgPu~_, pronounced as **/sharp magic/**==

> ###### What is "#Magic"?
> 
> After multiple iterations and user feedback, VLOOK™ has explored practical and elegant methods for quick image and video typesetting.
> 
> We can activate corresponding typesetting "magic" by adding URL anchors at the end of image or video addresses～
> 
> The usage method is by adding URL anchors "**#specific magic**" at the end of image paths
> 
> > Example:
> > 
> > - Images in Markdown are generally in this format: `![Alt text](image address.png)`
> > - If we want to set the image as an icon style, we can add `#icon` to scale to 200px width, we can add `#200w` ～

---

> **Quick Typesetting Applications for Images**
> 
> [Display Layout](#Image-Display-Layout), [Scaling](#Image-Scale), [Rotation](#Image-Rotation), [Flip](#Image-Flip), [Filter](#Image-Filter), [Grid Background](#Image-Grid-Background), [Edge Padding](#Image-Edge-Padding), etc.～

> **Quick Typesetting Applications for Videos**
> 
> Embedded videos from streaming platforms, specified as "[Vertical Display](guide2-en.md#Streaming-Platforms)", etc.

## Format Combinations and Special Cases

<u>VLOOK™ combines and specially uses conventional Markdown formats to innovatively achieve various personalized and practical typesetting capabilities.</u>

_^tab^_

> **Highlight**
> 
> The highlight color will adapt based on [Theme Color](vip-en.md), [Text Color](#Text-Color), [Text Gradient](#Text-Gradient), [Blockquote Coloring](#Blockquote-Coloring), [GitHub Style Alert](guide2-en.md#GitHub-Style-Alert).

> **Level 1 Heading, Level 6 Heading**
> 
> Using Markdown's level 1 heading `# Heading` and level 6 heading `###### Heading` in specific positions in the document achieves:
> 
> - "[Front and Back Covers](guide2-en.md#°Cover & Back Cover)"
> - "[Blockquote Subtitle](#Blockquote-Subtitle)"

*==Markdown Conventional Format Combinations==*

| Markdown Format Combinations | Implemented New Typesetting Features |
| ---------------------------- | ------------------------------------ |
| `` *`Tag`* `` | "[Tags](guide2-en.md#Tag)" |
| `*==Caption==*` when **occupying a single line** | "[Table Caption](#Table Caption & Auto-numbering)" "[Image Caption](#Image Caption & Auto-numbering)" "[Code Block Caption](guide2-en.md#Code Block Caption & Auto-numbering)" "[Multimedia Content Caption](guide2-en.md#Multimedia Caption & Auto-numbering)" |
| `*==Breadcrumbs==*` when not occupying a single line | "[Breadcrumbs](guide2-en.md#Breadcrumbs)" |
| `[<kbd>Button Link</kbd>](url)` | "[Button Links](guide2-en.md#Button-Links)" |
| `**==Progress Bar==**` | "[Progress Bars](guide2-en.md#Progress Bar)" |
| `*Hint**Scratch Card***` | "[Scratch Card](guide2-en.md#Scratch-Cards)" |
| `_~Color Code~_` [ⓘ](#Preset Color Code) | "[Text Color](#Text-Color)" "[Text Gradient](#Text-Gradient)" "[Colorful Tags](guide2-en.md#Tag)" "[Cell Coloring](#Cell-Coloring)" "[Scratch Card](guide2-en.md#Scratch-Cards)" "[Blockquote Coloring](#Blockquote-Coloring)" |
| `_^Tab Group^_` or `*^Tab Group^*` <br>when **occupying a single line** | "[Tab Group](guide2-en.md#°Tab Group)" |
| `_^Phonetic Notation^_` or `*^Phonetic Notation^*`<br>when not occupying a single line | "[Phonetic Notation](guide2-en.md#Phonetic-Notation)" |

# Preset Color Code

---

---

> **< One >**
> 
> Below are VLOOK™'s predefined color codes, where the two-character English abbreviations are color code markers, such as: `Ye` `Aq` `T1`, etc.

> **< Two >**
> 
> Will be used in subsequent [Text Color](#Text-Color), [Text Gradient](#Text-Gradient), [Cell Coloring](#Cell-Coloring), [Tags](guide2-en.md#Tag), [Scratch Card](guide2-en.md#Scratch-Cards), [Blockquote Coloring](#Blockquote-Coloring), etc.

> **< Three >**
> 
> Supports "**Regular**" and "**Emphasized**" styles. Adding an English exclamation mark "**!**" after the color code specifies the emphasized style, e.g.: `Ye!`

![VLOOK™ - Color Card Preset Color Code](pic/vlook-color-card-light.png?srcset=@2x&darksrc=vlook-color-card-dark.png&darksrcset=@2x#logo#center)

> **Syntax**
> 
> Set the "**Color Code**" to the following format combination: first "==Italic==", then "==Subscript=="
> 
> - Corresponding Markdown format syntax:
>   - Single color: `_~Color Code~_`, e.g.: `_~Ye~_` `_~Aq~_` `_~T1~_`
>   - Gradient color: `_~Color Code 1Color Code 2...Color Code n~_`, e.g.: `_~YeOg~_` `_~RdGnBuRo~_`
> 
> - After correctly setting the format combination, a special style will be displayed as a hint during editing (or after gaining focus), and it will take effect only after exporting the HTML file.

> [!IMPORTANT]
> 
> To distinguish from Typora's default italic marked with single asterisks `*italic*`, and to resolve conflicts with bold, the **italic** in **color codes** must use Markdown's other italic mark syntax (underscore `_`).

# ==Donate==

<u>**Thanks to the patrons who donated to support VLOOK™ (partial list) / Thanks for donate VLOOK™ (partial donors)**</u>

==**Peter**_~PuOgRd~_、**绿邃清幽**_~CyBuAq~_、**李导996**_~CyBuAq~_、**fanky**_~CyBuAq~_、**＊丽**_~CyBuAq~_、**杨琛**_~CyBuAq~_、**＊哦**_~GnBn~_、**＊豫**_~GnBn~_、**l＊a**_~GnBn~_、**＊o**_~GnBn~_、K＊y、行川、＊药、＊山、＊魂、＊士、＊狗、＊R、＊Z、＊川、l＊n、＊朽、＊杰、A＊C、W＊l、＊山、J＊o、韩宗辉、＊星、一叶知秋、d＊、＊军、＊鹏、＊无、H＊t、＊二、＊宇、＊辉、＊秋、＊笑、＊心、整＊9、＊国、＊哥、乌拉、＊龙、远方眼前、＊雩、＊应、＊销、E＊y、…==

---

> **Your coffee keeps VLOOK™ running ☕️**
> 
> [![Donate VLOOK™](pic/donate-paypal-light.png?darksrc=donate-paypal-dark.png&srcset=@2x&darksrcset=@2x#logo)](https://paypal.me/madmaxchow)
> 
> _~Se~_

> **Your coffee keeps VLOOK™ running ☕️**
> 
> ![Donate VLOOK™](pic/donate-wechat-light.png?darksrc=donate-wechat-dark.png&srcset=@2x&darksrcset=@2x#logo)
> 
> _~Gn~_

# °Text

## Text Color

*Markdown Fans`Q`*「**Specifying different colors for text is probably the second most requested feature by Markdown fans after table typesetting!**」

*VLOOK`A`*_~T2~_ achieves this easily through a concise method, let's take a look～

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

*==How to Make Your Markdown Document Text Colors More Vibrant (Bilibili)==*

<iframe src="https://player.bilibili.com/player.html?bvid=BV1zhaiegE73&page=1&autoplay=0" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>

_^tab^_

> **Text Color for "Specified Format"**
> 
> - Add predefined color codes after text with formats like "**bold**", *italic*, ==highlight==, <u>underline</u>, etc., e.g.: red `_~Rd~_`
> - For specific color code syntax, refer to [Preset Color Code](#Preset Color Code)

> **Text Color for "Entire Paragraph"**
> 
> The syntax is consistent with the left "Text Color for Specified Format", the difference is adding [Preset Color Code](#Preset Color Code) at the very beginning of the paragraph. After being correctly recognized, a paragraph marker "**¶**_~T2~_" will appear before the color code.

###### Text Color Example in Normal Paragraphs

_~Gd~_This is a paragraph where you can use **<u>predefined</u>** `color codes` to color the entire paragraph with ==color codes==.

1. Mark specified **bold text content**_~Rd~_ in the paragraph with color code combinations, also supporting special symbols: **●**_~Rd~_**●**_~Ye~_**●**_~Gn~_;
2. Or *specified italic text content*_~Bu~_ with color code **combinations for marking**_~Wt~_;
3. Or ==specified highlighted text content==_~Ro~_ with color code combinations for marking;
4. Or <u>specified underlined text content</u>_~Pu~_ with color code combinations for marking;
5. Or specified^superscript content^_~Gn~_,~subscript content~_~Gn~_ with color code combinations for marking.

###### Text Color Example in Blockquotes

---

> 1. Apply color codes to **specified bold text content**_~Rd~_ in the paragraph, also supporting special symbols: **●**_~Rd~_**●**_~Ye~_**●**_~Gn~_;
> 2. Or apply color codes to *specified italic text content*_~Gn~_;
> 3. Or apply color codes to ==specified highlighted text content==_~Ro~_;
> 4. Or apply color codes to <u>specified underlined text content</u>_~Pu~_.

> _~T1~_This is a paragraph where you can use **<u>predefined</u>** `color codes` to color the entire paragraph with ==color codes==.

*==Preset Color Code and Examples for Text Color==*

|    Color    | **Color Code** | Single Color Rendering Example                   |
| :---------: | :-----------: | ----------------------------------------------- |
| Wine Red | Wn | Warning, danger, critical matters, deletion_~Wn~_ |
| Red | Rd | Warning, danger, critical matters, deletion_~Rd~_ |
| Orange | Og | Reminder, attention, fix_~Og~_ |
| Yellow | Ye | Focus, optimization, memo, explanation_~Ye~_ |
| Lime Green | Lm | Hint, reference, addition_~Lm~_ |
| Green | Gn | Hint, reference, addition_~Gn~_ |
| Mineral Green | Mn | Hint, reference, addition_~Mn~_ |
| Olive Green | Ol | Hint, reference, addition_~Ol~_ |
| Aqua Green | Aq | Blockquote, announcement_~Aq~_ |
| Cyan | Cy | Blockquote, announcement_~Cy~_ |
| Blue | Bu | Information, news_~Bu~_ |
| Sea Blue | Se | Information, news_~Se~_ |
| Lavender Purple | La | Information, news_~La~_ |
| Vine Purple | Vn | Information, news_~Vn~_ |
| Purple | Pu | Extension, expansion, reservation, backup_~Pu~_ |
| Rose Pink | Ro | Youthful, personality, feminine_~Ro~_ |
| Pink | Pk | Youthful, personality, feminine_~Pk~_ |
| Gold | Gd | VIP, finance, engineering_~Gd~_ |
| Brown | Bn | VIP, finance, engineering_~Bn~_ |
| Gray | Gy | Invalid, postpone, deactivate, end_~Gy~_ |
| Black | Bk | Black and white, high contrast_~Bk~_ |
| Theme Primary Color | T1 | Current VLOOK™ theme's primary color_~T1~_ |
| Theme Secondary Color | T2 | Current VLOOK™ theme's secondary color_~T2~_ |

## Text Gradient

*Markdown Fans`Q`*「**Gradient text colors are becoming increasingly popular, it would be perfect if this could be supported too!**」

*VLOOK`A`*_~T2~_ The new [Preset Color Code](#Preset Color Code) support gradient colors, with a natural and intuitive writing style that will definitely impress you～

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

> - All rules are the same as "[Text Color](#Text-Color)", just change the color code from 1 to multiple consecutive inputs～
> - For example: "**Red-Green**_~RdGn~_" gradient is input as `_~RdGn~_`, "**Red-Yellow-Green**_~RdYeGn~_" gradient is input as `_~RdYeGn~_`
> - For specific color code syntax, refer to [Preset Color Code](#Preset Color Code)

###### Gradient Text Example in Normal Paragraphs

_~LmOgGnRd~_This is a paragraph using predefined `color codes` at the very beginning to color the entire paragraph.

1. Mark specified **bold text content**_~RoBuAq~_ in the paragraph with color code combinations **as gradient**_~RoBuAq~_;
2. Or *specified italic text content*_~OgRo~_ with color code combinations **as gradient**_~OgWt~_;
3. Or ==specified highlighted text content==_~BuAq~_ with color code combinations **as gradient**_~BuAq~_;
4. Or <u>specified underlined text content</u>_~SeRo~_ with color code combinations **as gradient**_~SeRo~_;
5. Or specified^superscript content^_~RdGn~_,~subscript content~_~RdGn~_ with color code combinations **as gradient**_~RdGn~_.

###### Gradient Text Example in Blockquotes

---

> 1. Mark specified **bold text content**_~RoBuAq~_ in the paragraph with color code combinations **as gradient**_~CySe~_;
> 2. Or *specified italic text content*_~SeGd~_ with color code combinations **as gradient**_~OgRo~_;
> 3. Or ==specified highlighted text content==_~AqPu~_ with color code combinations **as gradient**_~BuAq~_;
> 4. Or <u>specified underlined text content</u>_~OgBk~_ with color code combinations **as gradient**_~SeRo~_.

> _~LmOgGnRd~_This is a paragraph using predefined color codes at the very beginning to color the entire paragraph.

---

For feedback: [![Feedback via Email](pic/feedback-via-email.svg?darksrc=invert#icon)](mailto:67870144@qq.com?subject=Feedback%20about%20VLOOK™&body=Hi, "Feedback via Email")  [![Feedback via QQ](pic/feedback-via-qq.svg?darksrc=invert#icon)](https://qm.qq.com/q/O0tNC6WBWe "QQ Group (805502564)")  [![Feedback via Telegram](pic/feedback-via-telegram.svg#icon)](https://t.me/vlook_markdown "Join Telegram Channel")

# °Paragraph

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

Used to meet the need for personalized formatting of **an entire paragraph**, creating a differentiated style compared to regular body text.

Simply select all the content of the paragraph first, then apply the basic Markdown formatting (bold, underline, italic, highlight), such as: `**entire paragraph content**` `==entire paragraph content==` , etc.

## Paragraph Italic

Provides support for styling an **entire paragraph** with a distinct appearance from the main body text — typically used to de-emphasize content or format it as a reference note.  Example:

*~This is a paragraph that needs to be visually distinct from the main content, de-emphasized, or used as a ==reference note==. Everything else remains unchanged.~*

> **Italic paragraph style within blockquotes **
>
> (Currently not available)

*The above is the effect after applying "**paragraph Italic**" to the entire paragraph. (To disable this style, simply add a space at the end)* 



> [!TIP]
>
> The style of the above paragraph can be modified or disabled via the [Custom Theme](vip-en.md) .

## Paragraph Bold

Meets the need to center and emphasize the entire paragraph content. Example:

**～This is a paragraph that needs ==strong emphasis==, appearing in ==center alignment==. ==Bold==, ==larger font size==, ==centered==, others unchanged～**

> **Bold paragraph style within blockquotes **
>
> (Currently not available)

*The above is the effect after applying "**paragraph bold**" to the entire paragraph. (To disable this style, simply add a space at the end)* 



> [!TIP]
>
> The style of the above paragraph can be modified or disabled via the [Custom Theme](vip-en.md) .

## Paragraph Underline

Meets the need to slightly emphasize the entire paragraph content, with <u>visual separation</u> from subsequent content but still related. Example:

<u>～This is a paragraph with **slight emphasis**, **visual separation** from subsequent content, but still **related**. **Larger font size**, **centered**, others unchanged</u>

> **Underline paragraph style within blockquotes **
>
> <u>～This is a paragraph with **slight emphasis**, **visual separation** from subsequent content, but still **related**. **Larger font size**, **centered**, others unchanged</u>

*The above is the effect after applying "<u>underline</u>" to the entire paragraph. (To disable this style, simply add a space at the end)* 





> [!TIP]
>
> The style of the above paragraph can be modified or disabled via the [Custom Theme](vip-en.md) .

## Paragraph Highlight

Meets the need for the entire paragraph content to be displayed in a ==more personalized, more emphasized== quote style, with visual separation from preceding/following content. Example:

==～This is a paragraph with **more personality, more emphasis**_~RdPuRo~_, <u>visual separation</u> from preceding/following content. <u>Larger font size</u>, <u>centered</u>, others unchanged～==

> **Hightlight paragraph style within blockquotes **
>
> (Currently not available)

*The above is the effect after applying "==highlight==" to the entire paragraph. (To disable this style, simply add a space at the end)* 





> [!TIP]
>
> The style of the above paragraph can be modified or disabled via the [Custom Theme](vip-en.md) .



---

For feedback: [![Feedback via Email](pic/feedback-via-email.svg?darksrc=invert#icon)](mailto:67870144@qq.com?subject=Feedback%20about%20VLOOK™&body=Hi, "Feedback via Email")  [![Feedback via QQ](pic/feedback-via-qq.svg?darksrc=invert#icon)](https://qm.qq.com/q/O0tNC6WBWe "QQ Group (805502564)")  [![Feedback via Telegram](pic/feedback-via-telegram.svg#icon)](https://t.me/vlook_markdown "Join Telegram Channel")

# °Table

## Cell Merging

*Markdown Fans`Q`*「**What's the most requested feature by Markdown fans? ———— Cell merging!**」

*VLOOK`A`*_~T2~_ Now you can easily achieve this — Wow! Wow!～Cheers from Markdown fans!!!

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

---

> **![←](pic/i_merge1.svg?fill=text&darksrc=invert#icon) Cross-column Merge (Horizontal Merge)**
> 
> Input column merge marker `==` in the cell to be merged, and this cell will merge with the adjacent cell to the left, and so on.
> 
> _~T1~_

> **![↑](pic/i_merge2.svg?fill=text&darksrc=invert#icon) Cross-row Merge (Vertical Merge)**
> 
> Input row merge marker `:` in the cell to be merged, and this cell will merge with the adjacent cell above, and so on.
> 
> _~T2~_



_^tab^_

*==Example of Normal Cell Horizontal and Vertical Merging==*

| **Column A**        | Column B                | Column C                    | Column D            | Column E       | Column F       | Column G                                                         |
| -------------------- | ----------------------- | --------------------------- | ------------------- | -------------- | -------------- | ---------------------------------------------------------------- |
| Vertical Merge *`×3`* | Normal Cell          | Normal Cell              | Normal Cell          | Normal Cell | Normal Cell | `123` Vertical Merge *`×5`*<br>*Cell`Tag 1`*<br>*Cell`Tag 2`*_~Rd~_<br>*Cell`Tag 1`Tag 2*_~Gn!~_ |
| :                    | Vertical Merge *`×2`*     | Horizontal Merge *`×4`*         | ==                  | ==         | ==         | :                                                            |
| :                    | :                   | Normal**Cell==bold==**  | Normal*Cell`Tag`* | Normal Cell | Normal Cell | :                                                            |
| Normal Cell      | Vertical<br>Merge *`×3`* | Normal *Cell* Italic      | Normal Cell          | Normal Cell | Normal Cell | :                                                            |
| Normal Cell      | :                   | Normal==Cell==Highlight      | Normal Cell          | Normal Cell | Normal Cell | :                                                            |
| Normal Cell      | :                   | Normal<u>Cell</u>Underline | Normal Cell          | Normal Cell | Normal Cell | :                                                            |

*==Header Vertical and Horizontal Merge Example-1==*

| Column A Vertical Merge *`×2`* | Column B Horizontal Merge *`×2`* | ==         | Column D Vertical Merge *`×3`* | Column E Horizontal Merge *`×3`*   | ==       | ==        |
| -------------------- | -------------------- | ---------- | :------------------: | ---------------------- | ---------- | ---------- |
| :                    | Secondary Header             | Secondary Header   |          :          | Secondary Header<br>E1.1 | Secondary Header   | Secondary Header   |
| Normal Cell           | Normal Cell           | Normal Cell |       Normal Cell      | Normal Cell             | Normal Cell | Normal Cell |
| Normal Cell           | Normal Cell           | Normal Cell |       Normal Cell      | Normal Cell             | Normal Cell | Normal Cell |

*==Header Vertical and Horizontal Merge Example-2==*

| Column A Vertical Merge *`×3`* | Column B Horizontal Merge *`×4`* | ==           |      ==      | ==           | Column F Vertical Merge *`×3`* | Column G Vertical Merge *`×3`* |
| -------------------- | -------------------- | ------------ | :----------: | ------------ | -------------------- | -------------------- |
| :                    | Secondary Header B1          | ==           | Secondary Header B2  | ==           | :                    | :                    |
| :                    | Secondary Header B11         | Tertiary Header B12 | Tertiary Header B21 | Tertiary Header B21 | :                    | :                    |
| Normal Cell           | Normal Cell           | Normal Cell   |   Normal Cell  | Normal Cell   | Normal Cell           | Normal Cell           |
| Normal Cell           | Normal Cell           | Normal Cell   |   Normal Cell  | Normal Cell   | Normal Cell           | Normal Cell           |

## Table Column Formatting

### Basic

*Markdown Fans`Q`*「**How to quickly set whole column formatting (bold, highlight, italic) for Markdown tables?**」

*VLOOK`A`*_~T2~_ SO EASY～ Just set the corresponding format in the header using standard Markdown or GFM format syntax.

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

> Review standard Markdown or GFM format syntax:
> 
> `**bold**`, `*italic*`, `==highlight==`

*==Basic Column Formatting Example==*

| **Bold**           | *Italic*                   | ==Highlight==               | ~~Strikethrough~~         |
| ------------------ | ------------------------ | ---------------------- | ------------------ |
| Cell (Horizontal Merge) | ==                       | Cell                 | Strikethrough Column Cell 1 |
| Cell             | Cell ==afgiklo 10==    | Cell with**bold**content | Strikethrough Column Cell 2 |
| Cell             | Cell <u>afgiklo 10</u> | Cell content             | Strikethrough Column Cell 3 |

> [!NOTE]
>
> If a column is [not published to HTML](guide3-en.md#Mark Content not to Publish), you can set the corresponding column header to strikethrough format, i.e.: `~~Column Not Published~~`.

###### More Basic Column Formatting Examples

_^tab^_

*==Nested Basic Column Formatting==*

| **Bold** | ==**Bold＋Highlight**==     |
| -------- | ---------------------- |
| A        | Cell                 |
| B        | Cell with**bold**content |

*==Nested Basic Column Formatting (Multi-line Header)==*

| **Normal Column** | Nested Regular Format           | ==                | ==                     |
| ---------- | :----------------------- | ----------------- | ---------------------- |
| :          | **Bold**                 | *Italic*            | ==Highlight==               |
| A          | Cell <u>afgiklo 10</u> | Cell afgiklo 10 | Cell                 |
| B          | Cell ~~afgiklo 10~~    | Cell afgiklo 10 | Cell with**bold**content |

### Numeric

*Markdown Fans`Q`*「**Besides regular formats, are there more advanced format requirements? Numbers, percentages, currency... none can be missing!**」

*VLOOK`A`*_~T2~_ Supports automatic formatting for the above numeric content across entire columns! The approach remains elegant and very VLOOK!

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

==Set the table column alignment to "**right-align**" to automatically recognize different numeric content and automatically format it!==

> **![Normal Numbers](pic/i_digital.svg?fill=text&darksrc=invert#icon) "Normal Numbers" Auto-Formatting**
>
> - Uses "DIN" style font specifically for numbers
> - Adds thousand separators and displays decimals in smaller font size
> - Automatically prefixes numbers with "plus `+`" or "minus `-`", highlighted in different colors
>
> _~Rd!~_

*==Normal Numbers Example==*

| Original Content    |  Numeric Case  |    ==    |    ==    |     ==     |      |    Numeric Column |
| ----------- | :--------: | :------: | :------: | :--------: | ---- | ----------: |
| :           | []Decimal | []Positive | []Negative | []Over 3 Digits | :    |           : |
| 123         |            |          |          |            |      |         123 |
| -12345      |            |          |   Y    |    Y     | :    |      -12345 |
| +5678.00    |    Y     |   Y    |          |    Y     | :    |    +5678.00 |
| -2345678.00 |    Y     |          |   Y    |    Y     | :    | -2345678.00 |

> **![Percentage](pic/i_percent.svg?fill=text&darksrc=invert#icon) "Percentage" Auto-Formatting**
>
> - Inherits "Normal Numbers" format automatically
> - Displays percentage sign `%` in smaller font size and visually subdued, with progress bar showing corresponding percentage value
>
> _~Bu!~_

*==Percentage Column Format Example==*

| Original Content |  Numeric Case  |    ==    |    ==    |     ==     |      | Percentage Column |
| -------- | :--------: | :------: | :------: | :--------: | ---- | ------: |
| :        | []Decimal | []Positive | []Negative | []Over 3 Digits | :    |       : |
| 79%      |            |          |          |            |      |     79% |
| 88.88%   |    Y     |          |          |            | :    |  88.88% |
| +38%     |            |   Y    |          |            | :    |    +38% |
| -57.30%  |    Y     |          |   Y    |            | :    | -57.30% |
| 100%     |            |          |          |            | :    |    100% |

> **![Currency](pic/i_currency.svg?fill=text&darksrc=invert#icon) "Currency" Auto-Format**
>
> - Inherits "Normal Numbers" format automatically
> - Aligns currency symbols (e.g.: `¥` `$`), or currency abbreviations (e.g.: `CNY` `USD` `HKD`, etc.) to the left and visually subdues them
>
> _~Bn!~_

> [!IMPORTANT]
>
> There must be a space between the currency symbol/abbreviation and the amount value.

*==Currency Column Format Example==*

| **Currency** | Original Content      | Numeric Case |    ==    |     ==     |     ==     |      |  **Currency** |
| :------: | ------------- | :------: | :------: | :--------: | :--------: | ---- | ------------: |
|    :     | :             | []Positive | []Negative | []Decimal | []Over 3 Digits | :    |             : |
|   RMB  | ￥ +123456.99 |   Y    |          |    Y     |    Y     |      | ￥ +123456.99 |
|    :     | CNY 987654.99 |          |          |    Y     |    Y     | :    | CN¥ 987654.99 |
|    :     | CNY 987654.99 |          |          |    Y     |    Y     | :    | CNY 987654.99 |
|          | ==            |    ==    |    ==    |     ==     |     ==     | ==   |            == |
|   HKD   | HK\$ 3456.78  |   Y    |          |    Y     |    Y     |      |  HK\$ 3456.78 |
|    :     | HKD 3456.78   |          |          |    Y     |    Y     | :    |   HKD 3456.78 |
|          | ==            |    ==    |    ==    |     ==     |     ==     | ==   |            == |
|   USD   | \$ +555.38    |   Y    |          |    Y     |            |      |    \$ +555.38 |
|    :     | USD 555       |          |          |            |            | :    |       USD 555 |
|          | ==            |    ==    |    ==    |     ==     |     ==     | ==   |            == |
|   AUD   | AU\$ 56789    |   Y    |          |            |    Y     |      |    AU\$ 56789 |
|    :     | AUD -56789    |          |   Y    |            |    Y     | :    |    AUD -5678 |

### Checkbox

*Markdown Fans`Q`*「**For table column formatting, besides typesetting formats, what if we want to support checkboxes (tick boxes)?**」

*VLOOK`A`*_~T2~_ Although the requirements are higher, it can also be achieved by automatically setting the entire column to "checkbox" format!

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

> Add `[]` before the corresponding table column header content (e.g., `[]Required Field`) to automatically set the column to `unselected` state.
>
> To independently specify different states for a cell's checkbox, you can fill in the specified marker symbol at the very beginning of the cell content, such as:
>
> - *State`Selected`*: Add `Y` at the beginning of the cell content (case insensitive)
> - *State`Indeterminate`*: Add `?` at the beginning of the cell content (both Chinese and English question marks are supported)
> - *State`Unselected`*: Empty cell, or add `N` at the beginning of the cell content (case insensitive)
>

> [!NOTE]
>
> If the cell has more content, separate the above symbols and content with a space.

*=="Checkbox" Column Format Example==*

| **Checkbox Style** | Original Content of Checkbox Column      | []Checkbox Column        | Description                       |
| :------------: | :------------------------: | :-----------------------: | ------------------------- |
|      Empty      |  |  | Default to `unselected`    |
| Unselected | N | n | Specified as `unselected` |
| : | N Text | Y Text | Specified as `unselected`, with description text |
|     Selected     | Y |            y            | Specified as `selected`     |
| : | Y Text | Y Text | Specified as `selected`, with description text |
| No Marker Added | （N/A） | （N/A） | Default to no checkbox, and text will be distinguished by different colors |
|   Indeterminate   | ?<br>*When specified value`>=`0* | ?<br>*When specified value`>=`0* | Specified as `indeterminate` |
| : | ？<br>*When specified value`<`0* | ？<br>*When specified value`<`0* | : |

## Cell Coloring

*Markdown Fans`Q`*「**Table column formatting is rich enough, but can we use different background colors to identify individual cells?**」

*VLOOK`A`*_~T2~_ VLOOK™'s [Preset Color Code](#Preset Color Code) can be put to use again, same formula, same super easy to use!

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

---

> **Color Cell Text**
>
> Consistent with the method of coloring entire paragraphs in [Text Color](#Text-Color), just add [Preset Color Code](#Preset Color Code) at the very beginning of the cell, and a paragraph marker "**¶**_~T2~_" will appear before the color code after being correctly recognized, e.g.: red `_~Rd~_`

> **Color Cell "Background"**
>
> The method is the same as cell text coloring, the difference is using "emphasized" [Preset Color Code](#Preset Color Code) (e.g.: blue `_~Bu!~_`).
>
> If "cell text" coloring has been specified, you can add it at the ==end position==_~T2~_

_^tab^_

*==Example_Cell Coloring (Single Color)==*

|       Cell Coloring (Single Color Example)_~Bk!~_       |                 ==                  |                 ==                  |                   ==                    |                  ==                   |                 ==                 |                ==                 |                    ==                    |                     ==                     |
| :--------------------------------------: | :---------------------------------: | :---------------------------------: | :-------------------------------------: | :-----------------------------------: | :--------------------------------: | :-------------------------------: | :--------------------------------------: | :----------------------------------------: |
| **T1**_~T1~_<br>~Theme Primary Color•Theme1~_~T1!~_ |                  /                  |                 ==                  |                   ==                    |                  ==                   |                 ==                 |                ==                 |                    ==                    | **T2**_~T2~_<br>~Theme Secondary Color•Theme2~_~T2!~_ |
|     _~Gd~_**Gd**<br>~Gold•Gold~_~Gd!~_     | _~Pk~_**Pk**<br/>~Pink•Pink~_~Pk!~_ |                  /                  |   _~Ye~_**Ye**<br/>~Yellow•Yellow~_~Ye!~_   |  _~Lm~_**Lm**<br>~Lime•Lime~_~Lm!~_   | _~Aq~_**Aq**<br>~Aqua•Aqua~_~Aq!~_ |                 /                 | _~La~_**La**<br>~Lavender•Lavender~_~La!~_ |     _~Wt~_**Wt**<br/>~White•White~_~Wt!~_     |
|    _~Bn~_**Bn**<br>~Brown•Brown~_~Bn!~_    | _~Ro~_**Ro**<br/>~Rose•Rose~_~Ro!~_ |  _~Rd~_**Rd**<br/>~Red•Red~_~Rd!~_   |   _~Og~_**Og**<br/>~Orange•Orange~_~Og!~_   |   _~Gn~_**Gn**<br>~Green•Green~_~Gn!~_   |  _~Cy~_**Cy**<br>~Cyan•Cyan~_~Cy!~_  | _~Bu~_**Bu**<br>~Blue•Blue~_~Bu!~_  |    _~Vn~_**Vn**<br>~Vine•Vine~_~Vn!~_    |      _~Gy~_**Gy**<br>~Gray•Gray~_~Gy!~_      |
|                    /                     | _~Pu~_**Pu**<br/>~Purple•Purple~_~Pu!~_ | _~Wn~_**Wn**<br/>~Wine•Wine~_~Wn!~_ | _~Ol~_**Ol**<br/>~Olives•Olives~_~Ol!~_ | _~Mn~_**Mn**<br>~Mineral•Mineral~_~Mn!~_ |                 /                  | _~Se~_**Se**<br>~Sea•Sea~_~Se!~_ |                    /                     |     _~Bk~_**Bk**<br>~Black•Black~_~Bk!~_      |

*==Example_Cell Coloring (Gradient Color)==*

| Cell Coloring Example (**Custom Gradient Color Combination Example**_~T1T2~_)_~T1T2!~_ |                   ==                   |               ==               |               ==               |
| :----------------------------------------: | :------------------------------------: | :----------------------------: | :----------------------------: |
|   _~RdSe!~_Red-Sea Blue Dual Gradient<br>**RdSe**_~RdSe~_   | _~OgVn!~_Orange-Vine Dual Gradient<br>**OgVn**_~OgVn~_ | _~YePu!~_Yellow-Purple Dual Gradient<br>**YePu**_~YePu~_ | _~LmRo!~_Lime-Rose Dual Gradient<br>**LmRo**_~LmRo~_ |
|       _~GnPk!~_Green-Pink Dual Gradient<br>**GnPk**_~GnPk~_       |     _~AqGd!~_Aqua-Gold Dual Gradient<br>**AqGd**_~AqGd~_     | _~CyBn!~_Cyan-Brown Dual Gradient<br>**CyBn**_~CyBn~_ | _~BuGy!~_Blue-Gray Dual Gradient<br>**BuGy**_~BuGy~_ |
| _~BkRdGnBuBn!~_Black-Red-Green-Blue-Brown Multi Gradient<br>**BkRdGnBuBn**_~BkRdGnBuBn~_ |                   ==                   |               ==               |               ==               |

## Table Row Grouping & Folding

*Markdown Fans`Q`*「**Table rows are all at the same hierarchical level, but what if the table data has hierarchical relationships?**」

*VLOOK`A`*_~T2~_ Supports grouping and hierarchical specification for rows within tables through very concise markers.

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

> For subordinate rows, automatic grouping and folding can be achieved by following these rules in the first column of the table row:
>
> - Use Markdown's blockquote syntax `>␣` to indicate one level of indentation, with the preceding row as the parent group
> - Multiple `>` indicate multiple levels of indentation, e.g., three levels of indentation `>>>␣`
>
> <sup>**Note:** The `␣` symbol above represents an English space</sup>

> [!IMPORTANT]
>
> The content of this cell cannot independently set formats for partial content, such as partial text bold, highlight, line breaks, etc.

_^tab^_

*==Writing Method as Shown in Column 2 Below==*

| Grouping Hierarchy                              | Writing Example (Note: This column should be the first column of the table in actual application) |
| ------------------------------------- | ----------------------------------------------- |
| One Level Indentation                              | > This is one level indentation                                  |
| Two Levels Indentation                              | >> This is two levels indentation                                 |
| Three Levels Indentation                              | >>> This is three levels indentation                                |
| _~T2!~_ (**More levels follow this pattern**)_~T2~_ | ==                                              |

*==Example 1_Table Row Grouping & Folding==*

|     Biological Classification     | Column B   | Column C   |
| :--------------: | ------ | ------ |
|       Animals       |        |        |
|    > Vertebrates    |        |        |
|   >> Mammals    |        |        |
|     >>> Humans     |        |        |
|     >> Birds      |        |        |
|      >>> Chickens      |        |        |
|     >> Fish      |        |        |
|     >>> Sea Fish     |        |        |
|      >>>> -      | Salmon | Cod |
|      >>>> -      | Beltfish   | Tuna |
|    >>> Freshwater Fish    |        |        |
|   > Invertebrates   |        |        |
|     >> Insects      |        |        |
|     >>> Butterflies     |        |        |
|   >> Mollusks    |        |        |
|     >>> Octopuses     |        |        |
|       Plants       |        |        |
|    > Angiosperms    |        |        |
|  >> Dicotyledons   |        |        |
|     >>> Tomatoes     |        |        |
|  >> Monocotyledons   |        |        |
|     >>> Rice     |        |        |
|    > Gymnosperms    |        |        |
|     >> Pine Trees      |        |        |
|       Fungi       |        |        |
|      > Mushrooms      |        |        |
|      > Yeast      |        |        |
|       Bacteria       |        |        |
|    > E. coli    |        |        |
| > Staphylococcus aureus |        |        |

*==Table Row Grouping & Folding Example==*

| Column A                                          | []Check Column | Column B             |
| --------------------------------------------- | :--------: | ---------------- |
| Normal Row                                        |            |                  |
| Group 1                                        |    ?     |                  |
| > This belongs to Group 1 content 1.1                   |    Y     | This row is folded |
| > This belongs to Group 1 content 1.2                   |            | This row is folded |
| ==Group 2 (with formatting)== |  | |
| > This belongs to **continuous grouping** content 2.1              |    Y     | This row is folded |
| > This belongs to continuous grouping content 2.2                  |            | This row is folded |
| > This belongs to **==continuous grouping==** content 2.3          |    ?     | This row is folded |
| >> This belongs to level 2 **group 2.3** content 2.3.1      |            | This row is folded |
| >> This belongs to level 2 **group 2.3** content 2.3.2      |    ?     |                  |
| >>> This belongs to level 3 **group 2.3.2** content 2.3.2.1 |    Y     | This row is folded |
| >>> This belongs to level 3 group 2.3.2 content 2.3.2.2     |            | This row is folded |
| >>>> This belongs to group **2.3.2.2** content 2.3.2.1 |    Y     | This row is folded |
| >>> This belongs to level 3 group 2.3.2 content 2.3.2.3   |            | This row is folded |
| > This belongs to group 2 content 2.4                   |            | This row is folded |
| >> This belongs to level 2 group 2.4 content 2.4.1          |            | This row is folded |
| >> This belongs to level 2 group 2.4 content 2.4.2          |    Y     | This row is folded |
| > This belongs to group 2 content 2.5                   |            | This row is folded |
| > This belongs to group 2 content 2.6                   |            | This row is folded |
| Normal Row                                        |    Y     | Cell content       |

## Table Wrapping Layout

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

_^tab^_

> **For Tables**
>
> Default is "auto-wrap" layout, adjusted to "no-wrap" in the following cases:
>
> - Small screens (generally screen width less than `1280px`)
> - Tables with "[Row Grouping & Folding](#Table Row Grouping & Folding)", or tables with more than `7` columns
>
> _~T1~_

> **For Cells**
>
> Fine-tune cell styles for different situations:
>
> - Default minimum cell width is `120px`
> - Empty cells that are unique in a row or column will display as separator line style
> - For tables with row grouping, minimum width of first column is `180px`
> - When table is in "no-wrap" layout, maximum width for cells with excessive content is `330px`
>
> _~T2~_

*==Columns < 7==*

| Column A                                                         | Column B             |                         Column C                         |              Column D |
| ------------------------------------------------------------ | ---------------- | :-------------------------------------------------: | ---------------: |
| First Row                                                       | Left-align (Long Content) | Center-align (It's too long, too long content) Center-align | Right-align (Long Content) |
| Second Row (This is very long, very long, very long, very long, very long content in the cell) | Left-align           |                      Center-align                       |            Right-align |

*==Columns ≥ 7==*

| Column A                                                         | Column B             | Column C | Column D | Column E | Column F |                         Column G                         |             Column H |
| ---------------------------------------------------------------- | -------------------- | -------- | -------- | -------- | -------- | :-----------------------------------------------------: | -------------------: |
| First Row                                                       | Left-aligned (Long Content) |      |      |      |      | Center-aligned (It's too long, too long content) Center-aligned | Right-aligned (Long Content) |
| Second Row (This is very long, very long, very long, very long, very long content in a cell) | Left-aligned           |      |      |      |      |                       Center-aligned                       |            Right-aligned |

> [!TIP]
>
> The line-wrapping layout is for exported HTML, and can also be manually switched through the table [Content Assistant](guide3-en.md#Line Wrap Layout)'s "Line-Wrapping Layout".

## Table Alignment

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

The table alignment (left-aligned, centered) is specified by the selected VLOOK™ theme, and can be customized through [Custom Theme Service](vip-en.md).

## Table Caption & Auto-numbering

<u>About table captions and auto-numbering</u>

[<kbd>Relevant content can be found here ❯❯</kbd>](guide2-en.md#°Caption)

---

For feedback: [![Feedback via Email](pic/feedback-via-email.svg?darksrc=invert#icon)](mailto:67870144@qq.com?subject=Feedback%20about%20VLOOK™&body=Hi, "Feedback via Email")  [![Feedback via QQ](pic/feedback-via-qq.svg?darksrc=invert#icon)](https://qm.qq.com/q/O0tNC6WBWe "QQ Group (805502564)")  [![Feedback via Telegram](pic/feedback-via-telegram.svg#icon)](https://t.me/vlook_markdown "Join Telegram Channel")

# °Image

## Image Display Layout

*Markdown Fans`Q`*「**How to uniformly size mixed text-image icons and specify images not to be processed as "Figure"?**」

*VLOOK`A`*_~T2~_ VLOOK™ displays images as "Figure" by default, but can easily switch to more flexible display layouts using "[#Magic](##Magic)".

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

> Add VLOOK™ standard image "[#Magic](##Magic)" in the "image address" to implement various non-illustration layouts:
>
> - Image address + `#layout identifier`

*==Image Display Layout Identifiers and Descriptions==*

|     **Category**      |     Layout ID     | Description                                                 |
| :-------------------: | :--------------: | ------------------------------------------------------------ |
|     Icon Layout      |        ==        | ==                                                           |
|     Standard Size      |      #icon       | Reduced to small icons matching body text height<br>Mainly for mixed arrangement with body content |
|     2x Size      |   #icon**2x**    | Reduced to 2x body text height icons                        |
|     Logo Layout     |        ==        | ==                                                           |
|     Default Alignment      |      #logo       | Doesn't resize image and doesn't treat as "illustration"<br>Mainly for displaying original size and style |
| Logo Layout Extensions |        ==        | ==                                                           |
|       Left Aligned       |  #logo**#left**  | Based on `#logo`, supports text wrapping (image **left aligned**) |
|       Right Aligned       | #logo**#right**  | Based on `#logo`, supports text wrapping (image **right aligned**) |
|      Add Border      | #logo**#border** | Based on `#logo`, adds border style                          |

> [!NOTE]
>
> If you have questions about "URL parameters, URL anchors", you can learn more at [Image Address Extension Usage](guide3-en.md#Image Address Extension Notes).

### Icon Layout Examples

- **icon:** ![VLOOK](pic/vlook-light.svg?darksrc=vlook-dark.svg#icon) **VLOOK™** is ![OSChina](pic/oschina.png#icon) **[Open Source China](https://www.oschina.net/p/vlook)** recommended domestic open source project, perhaps one of the best Markdown enhancement plugins currently
- **icon2x:** ![VLOOK](pic/vlook-light.svg?darksrc=vlook-dark.svg#icon2x) **VLOOK™** is ![OSChina](pic/oschina.png#icon2x) **[Open Source China](https://www.oschina.net/p/vlook)** recommended domestic open source project, perhaps one of the best Markdown enhancement plugins currently

### Logo Layout Examples

###### Specified as `logo` mode

![Logo Mode](pic/vlook-mark-light.svg?darksrc=invert#logo)

> [!TIP]
>
> - To left-align `logo` layout images, just add an English space after the image;
> - For dark images/icons, you can also use "[Image Adaptation for Dark Mode](#Image Adaptation for Dark Mode)" to better adapt to Dark Mode display - try pressing the <kbd>D</kbd> key now to see the changes in the image below～

---

###### Specified as `#logo#left` mode

![Logo Mode: Left Aligned + Text Wrapping](pic/vlook-mark-light.svg?darksrc=invert#logo#left)**After setting to `#logo#left` mode, achieves left-aligned image + text wrapping effect**. Let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK.

---

###### Specified as `#logo#right` mode

![Logo Mode: Right Aligned + Text Wrapping](pic/vlook-mark-light.svg?darksrc=invert#logo#right)**After setting to `#logo#right` mode, achieves right-aligned image + text wrapping effect**. Let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK, let me add some filler text Hello VLOOK.

## Image Scale

*Markdown Fans`Q`*「**Hope to freely set image scaling size to adapt different sized images in documents**」

*VLOOK`A`*_~T2~_ Markdown doesn't support image scaling, but now with VLOOK™'s "[#Magic](##Magic)" it's easily achievable～

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

> Add VLOOK™ standard image "[#Magic](##Magic)" in the "image address" to implement:
>
> - Image address + `#scaling value`

*==Image Scaling Value Descriptions==*

|       **Scaling Type**        | Description                                                 | Full Syntax Reference            |
| :----------------------------: | ------------------------------------------------------------ | -------------------------------- |
| ==Width== by specified **percentage %**  | Height changes proportionally<br>Supports `20%` `40%` `60%` `80%` width levels | `![Image](xxx.png#80%)`  |
| ==Width== by specified **pixels px** | Height changes proportionally<br>Supports `200w` `400w` `600w` `800w` width levels<br><sup>If specified width exceeds browser display width, will auto-adapt to 100%</sup> | `![Image](xxx.png#600w)` |
| ==Height== by specified **pixels px** | Width changes proportionally<br>Supports `200h` `400h` `600h` `800h` width levels | `![Image](xxx.png#400h)` |

_^tab^_

> [!TIP]
>
> If proportional scaling isn't required, supports simultaneously specifying width and height.

> [!NOTE]
>
> If you have questions about "URL parameters, URL anchors", you can learn more at [Image Address Extension Usage](guide3-en.md#Image Address Extension Notes).

###### Width Scaling by Percentage Examples

_^tab^_

![Scale proportionally to 20% of document width](pic/vlook-zoom-pic.png#20%#padding)

![Scale proportionally to 40% of document width](pic/vlook-zoom-pic.png#40%#padding)

![Scale proportionally to 60% of document width](pic/vlook-zoom-pic.png#60%#padding)

![Scale proportionally to 80% of document width](pic/vlook-zoom-pic.png#80%#padding)

###### Width Scaling by Pixels Examples

_^tab^_

![Scale proportionally to 200px width](pic/vlook-zoom-pic.png#200w#padding)

![Scale proportionally to 400px width](pic/vlook-zoom-pic.png#400w#padding)

![Scale proportionally to 600px width](pic/vlook-zoom-pic.png#600w#padding)

![Scale proportionally to 800px width](pic/vlook-zoom-pic.png#800w#padding)

###### Height Scaling by Pixels Examples

_^tab^_

![Scale to 200px height](pic/vlook-zoom-pic-v.png#200h#padding)

![Scale to 400px height](pic/vlook-zoom-pic-v.png#400h#padding)

![Scale to 600px height](pic/vlook-zoom-pic-v.png#600h#padding)

![Scale to 800px height](pic/vlook-zoom-pic-v.png#800h#padding)

## Image Rotation

*Markdown Fans`Q`*「**Hope to quickly rotate images directly**」

*VLOOK`A`*_~T2~_ Markdown doesn't support image rotation, but now with VLOOK™'s "[#Magic](##Magic)" it's easily achievable～

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

> Add VLOOK™ standard image "[#Magic](##Magic)" in the "image address" to implement (currently only supports 180 degree rotation):
>
> - Image address + `#180deg`

###### Image Rotation Example

---

> ![Original](pic/j20.jpg)

> ![Rotated 180 degrees](pic/j20.jpg#180deg)

## Image Flip

*Markdown Fans`Q`*「**Hope to quickly flip images horizontally or vertically**」

*VLOOK`A`*_~T2~_ Markdown doesn't support image flipping, but now with VLOOK™'s "[#Magic](##Magic)" it's easily achievable～

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

> Add VLOOK™ standard image "[#Magic](##Magic)" in the "image address" to implement:
>
> - **Horizontal Flip**: Image address + `#fliph`
> - **Vertical Flip**: Image address + `#flipv`

###### Image Flipping Example

![Original](pic/j20.jpg)  ![Horizontal Flip](pic/j20.jpg#fliph)  ![Vertical Flip](pic/j20.jpg#flipv)

## Image Filter

*Markdown Fans`Q`*「**Hope to add some simple, practical filters to images (e.g. invert, blur, grayscale, vintage)**」

*VLOOK`A`*_~T2~_ Markdown doesn't support image filters, but now with VLOOK™'s "[#Magic](##Magic)" it's easily achievable～

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

_^tab^_

> **Syntax**
>
> Add VLOOK™ standard image "[#Magic](##Magic)" in the "image address" to implement:
>
> - **Invert**: Image address + `#invert`
> - **Blur**: Image address + `#blur`
> - **Vintage**: Image address + `#aged`
> - **Grayscale**: Image address + `#gray`

> ==Advanced Usage==
>
> If you want filtered images to restore to original when hovered, it's very Easy～
>
> Just add an English exclamation mark `!` after the above mentioned "**#Magic**"～

> [!NOTE]
>
> For the same image, these "**#Magic**" cannot be used simultaneously

###### Image Filter Examples

![Vintage Filter](pic/j20.jpg#200w#invert)  ![Blur Filter](pic/j20.jpg#200w#blur)  ![Grayscale Filter](pic/j20.jpg#200w#aged)  ![Vintage Filter](pic/j20.jpg#200w#gray)

###### Hover to Restore Original Examples

![Hover to Remove Vintage Filter](pic/j20.jpg#200w#invert!)  ![Hover to Remove Blur Filter](pic/j20.jpg#200w#blur!)  ![Hover to Remove Grayscale Filter](pic/j20.jpg#200w#aged!)  ![Hover to Remove Vintage Filter](pic/j20.jpg#200w#gray!)

## Image Grid Background

*Markdown Fans`Q`*「**When using engineering or design images, hope to automatically add uniform grids as background**」

*VLOOK`A`*_~T2~_ Through "[#Magic](##Magic)", you can add specified grid backgrounds for transparent background images (like PNG, SVG).

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

> Add VLOOK™ standard image "[#Magic](##Magic)" in the "image address" to implement:
>
> - Image address + `#grid background identifier`
>
> This feature automatically adapts to images also using [Dark Mode](guide3-en.md#Dark-Mode).

*==Image Grid Background Identifiers and Descriptions==*

| Grid Background ID | Description                   | Full Syntax Reference             |
| :----------: | ---------------------- | -------------------------------- |
|     line     | Add line-style grid background | `![Image](xxx.png#line)`  |
|    block     | Add block-style grid background | `![Image](xxx.png#block)` |

###### Line Grid Background Examples

_^tab^_

![Image with Line Grid Background (Invert in Dark Mode)](pic/icon-set.svg?darksrc=invert#line "Specify to invert in Dark Mode")

![Image with Line Grid Background (Specify Image in Dark Mode)](pic/vlook-mark-light.svg?darksrc=vlook-mark-dark.svg#padding#line "Specify Image in Dark Mode")

###### Block Grid Background Examples

_^tab^_

![Image with Block Grid Background (Invert in Dark Mode)](pic/icon-set.svg?darksrc=invert#block "Specify to invert in Dark Mode")

![Image with Block Grid Background (Specify Image in Dark Mode)](pic/vlook-mark-dark.svg?#padding#block "Specify Image in Dark Mode")

## Image Edge Padding

*Markdown Fans`Q`*「**My figure have no edge padding, visually looking crowded, how to adjust?**」

*VLOOK`A`*_~T2~_ Through "[#Magic](##Magic)" this niche personalized typesetting challenge can be easily handled～

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

> **Syntax**
>
> Add VLOOK™ standard parameter in "image address" to enable this feature (default adds `20px` padding to image edges):
>
> - Image address + `#padding`, example: `![Image Caption](xxx.png#padding)`

> [!NOTE]
>
> If you have questions about "URL parameters, URL anchors", you can learn more at [Image Address Extension Usage](guide3-en.md#Image Address Extension Notes).

![Image without Edge Padding (Default)](pic/remote-control.svg#block)![Image with Edge Padding](pic/remote-control.svg#block#padding)

## Postcard

*Markdown Fans`Q`*「**Most HTML generated by Markdown is static, can it bring some more modern designs in terms of interactivity?**」

*VLOOK`A`*_~T2~_ With "[#Magic](##Magic)"加持, automatic image-text typesetting reaches new heights, monotonous images instantly become lively～

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

_^tab^_

> **Postcard Syntax**
>
> Add VLOOK™ standard image "[#Magic](##Magic)" in the "image address" to implement:
>
> - **Hover Mode**[^hover-mode]: Image address + `#card`
> - **Flat Mode**[^flat-mode]: Image address + `#cardd`
>
> When a theme-colored border appears at the bottom of the image, it means it's correctly enabled. After exporting HTML, supports browsing and searching in illustration index.
>
> > [!TIP]
> >
> > If image edges are white or you want images to stand out, you can append `#border` to achieve this

> **Postcard Title and Body**
>
> Standard Markdown image syntax:
>
> `![Alt text](xxx.png#card "Title text")`
>
> Note that card title content comes from "**Title text**" in the image, while card body content comes from "**Alt text**" in the image.
>
> 
>
> > [!TIP]
> >
> > To customize body content formatting, you can add a "**blockquote**" below the image, whose content will replace "**Alt text**".

[^hover-mode]: Mouse ==hover to display== text (directly displays on mobile browsers)
[^flat-mode]: Image and text ==display simultaneously==

_^tab^_

> [!CAUTION]
>
> "Postcard" cannot be used simultaneously with typesetting features in [Image Display Layout](#Image-Display-Layout).

> [!NOTE]
>
> If you have questions about "URL parameters, URL anchors", you can learn more at [Image Address Extension Usage](guide3-en.md#Image Address Extension Notes).

###### Adding Postcard to Any Ordinary Image (Single Card) Example

![Lava and forest next to each other. Lava and forest next to each other.](pic/pic-card-00.jpeg#card#400w "Sicily")

###### Adding Postcard to Any Ordinary Image (Single Card+Border) Example

![Lava and forest next to each other. Lava and forest next to each other.](pic/pic-card-04.jpg#card#border#400w "Sicily")

###### Adding Postcard to Any Ordinary Image (Dual Card) Example

![Lava and forest next to each other. Lava and forest next to each other.](pic/pic-card-00.jpeg#cardd#400w "Sicily")

###### Adding Postcard to Any Ordinary Image (Dual Card+Border) Example

![Lava and forest next to each other. Lava and forest next to each other.](pic/pic-card-00.jpeg#cardd#border "Sicily")

###### Postcard with Blockquote Coloring (Dual Card) Example

> ![Lava and forest next to each other. Lava and forest next to each other.](pic/pic-card-00.jpeg#cardd "Sicily")
>
> _~Gn~_

> **Advanced Usage**
>
> - If you want to typeset Postcard more neatly in **columns**_~T1T2~_, just place "Postcard" inside [colored blockquotes](#Blockquote-Coloring)
> - If blockquotes specify **background colors**_~T1T2~_, will adapt for display, same familiar recipe～
> - After adding `#border` to images, when image width is too small to fill column space, you can additionally add `#fill` parameter,
> - If image width is small, you can try adding `#fitmax` to image address to make hover-displayed cards wider, see example [❯❯](guide3-en.md#Font Style)
>
> _~Bk!~_

###### Single Card Example with Blockquote Columns

---

---

> ![Replaced Body Content](pic/pic-card-01.jpeg#card "Guangdong Science Center")
>
> > With **"Nature, Humanity, Science, Civilization"**_~RdGnSe~_ as its theme, this non-profit public welfare organization serves as a social science activity venue for public science education and a demonstration site for science tourism leisure.
> >
> > [<kbd>View on Baidu Baike</kbd>](https://baike.baidu.com/item/%E5%B9%BF%E4%B8%9C%E7%A7%91%E5%AD%A6%E4%B8%AD%E5%BF%83)  View on [Baidu Baike](https://baike.baidu.com/item/%E5%B9%BF%E4%B8%9C%E7%A7%91%E5%AD%A6%E4%B8%AD%E5%BF%83)
> >
> > ---
> >
> > *<sub>Guangdong Science Center cost 1.9 billion RMB and took nearly 5 years to build, opening on September 26, 2008.</sub>*
>
> _~T1~_

> ![Samburu warriors standing on an autumn ridge, surrounded by the 975,000-acre Namunyak Wildlife Conservancy in northern Kenya. — Photo: AMI VITALE, NAT GEO IMAGE COLLECTION](pic/pic-card-02.jpeg#card#border)
>

> ![Pelicans (also called gannets or river birds, large swimming birds in the order Pelecaniformes, family Pelecanidae, genus Pelecanus, with broad wings, wide wingspan, powerful flapping), flying over Medicine Lake National Wildlife Refuge in Montana. The bird in the foreground has a horny plate on its beak that grows during mating season and falls off when the season ends. — Photo: KLAUS NIGGE, NAT GEO IMAGE COLLECTION](pic/pic-card-03.jpeg#card#border "Pelicans")
>
> _~Mn~_

###### Flat Mode Example with Blockquote Columns

---

---

> ![](pic/pic-card-01.jpeg#cardd "Guangdong Science Center")
>
> > With **"Nature, Humanity, Science, Civilization"**_~LmOgYe~_ as its theme, this non-profit public welfare organization serves as a social science activity venue for public science education.
> >
> > [<kbd>View on Baidu Baike</kbd>](https://baike.baidu.com/item/%E5%B9%BF%E4%B8%9C%E7%A7%91%E5%AD%A6%E4%B8%AD%E5%BF%83)  View on [Baidu Baike](https://baike.baidu.com/item/%E5%B9%BF%E4%B8%9C%E7%A7%91%E5%AD%A6%E4%B8%AD%E5%BF%83)
> >
> > ---
> >
> > *<sub>Guangdong Science Center cost 1.9 billion RMB and took nearly 5 years to build, opening on September 26, 2008.</sub>*
>
> _~Bu~_

> ![Standing on an autumn ridge, surrounded by the 975,000-acre Namunyak Wildlife Conservancy in northern Kenya. — Photo: AMI VITALE, NAT GEO IMAGE COLLECTION](pic/pic-card-02.jpeg#cardd#border "Samburu Warriors")
>

> ![](pic/pic-card-03.jpeg#cardd#border "Pelicans")
>
> > **Pel_^tí^_can_^hú^_ (also called gannets or river birds, large swimming birds in the order *Pelecaniformes*, family *Pelecanidae*, with broad wings, wide wingspan, powerful flapping)**, flying over Medicine Lake National Wildlife Refuge in Montana. The bird in the foreground has a horny plate on its beak that grows during mating season and falls off when the season ends.
> >
> > *<sub>— Photo: KLAUS NIGGE, NAT GEO IMAGE COLLECTION</sub>*
>
> _~Gn~_

## Image HD Screen Adaptation

*Markdown Fans`Q`*「**Images appear blurry on HD screens, but Markdown image syntax doesn't support different resolution image sets, what to do?**」

*VLOOK`A`*_~T2~_ While keeping Markdown image syntax unchanged, easily display HD resolution images on high-resolution screens!

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

<u>Add VLOOK™ standard parameters in "image address" to enable this feature.</u>

_^tab^_

> **Not Using "Image Hosting"**
>
> ---
>
> > **Syntax Without Image Hosting** 
> >
> > `srcset=@2x,@3x`
>
> > **Example** 
> >
> > `![](my-image.png?srcset=@2x)`

> **Using "Image Hosting"**
>
> ---
>
> > **Syntax for using "Image Hosting" (random naming)**
> >
> > `srcset=<2x image path>@2x,<3x image path>@3x`
>
> > **Example**
> >
> > `![](2WY6eq.jpg?srcset=3yEIwd.jpg@2x)`
> >
> > 

> [!NOTE]
>
> - For high-resolution images in the same directory or URL as standard resolution images, only the filename needs to be written; otherwise, the complete image address must be provided.
> - If you have questions about "URL parameters, URL anchors", you can learn more at "[Image Address Extension Notes](guide3-en.md#Image Address Extension Notes)".

_^tab^_

![Standard resolution image](pic/iphone-home-light.png?darksrc=iphone-home-dark.png)

![Supports 2x resolution image](pic/iphone-home-light.png?darksrc=iphone-home-dark.png&srcset=@2x&darksrcset=@2x)

![Supports 2x, 3x resolution images](pic/iphone-home-light.png?darksrc=iphone-home-dark.png&srcset=@2x,@3x&darksrcset=@2x,@3x)

## Image Adaptation for Dark Mode

*Markdown Fans`Q`*「**When the system enables Dark Mode, the images appear somewhat inharmonious. What should I do?**」

*VLOOK`A`*_~T2~_ Supports specifying adaptation methods for images in Dark Mode, currently supporting "**invert colors**" and "**replace**" to meet different needs!

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

### Invert Color Adaptation

> **Particularly suitable for "black/white/gray" type images**
>
> Add VLOOK™ standard URL parameters in "image address":
>
> - URL parameter: `darksrc=invert`
>
> ---
>
> **You can now click the ![](pic/icon-auto-mode.svg#icon) / ![](pic/icon-light-mode.svg#icon) / ![](pic/icon-dark-mode.svg#icon) in the bottom right corner (shortcut <kbd>D</kbd>), then observe the changes in the two images below.**

> [!NOTE]
>
> If you have questions about "URL parameters, URL anchors", you can learn more at "[Image Address Extension Notes](guide3-en.md#Image Address Extension Notes)".

_^tab^_

![Black and white image not adapted for dark mode](pic/iphone.jpg?srcset=@2x#padding)

![Black and white image adapted for dark mode: invert](pic/iphone.jpg?srcset=@2x&darksrc=invert#padding)

### Replacement Adaptation

> In the "image address", add VLOOK™ standardized URL parameters to achieve:
>
> URL parameters:
>
> - Normal resolution image: `darksrc=xxx.jpg`
> - High-definition screen resolution adaptation (optional): `darksrcset=...`, the usage of this parameter is consistent with `srcset` for ==high-definition screen adaptation==, see "[Image HD Screen Adaptation](#Image HD Screen Adaptation)"
>
> ---
>
> **You can now click the bottom right ![](pic/icon-auto-mode.svg#icon) (shortcut <kbd>D</kbd>), then observe the changes in the two images below～**

_^tab^_

> [!IMPORTANT]
>
> If high-resolution image resources are large, after switching to Dark Mode, the specified image resources need to be loaded completely before being replaced.

> [!NOTE]
>
> If you have questions about "URL parameters, URL anchors", you can learn more at "[Image Address Extension Notes](guide3-en.md#Image Address Extension Notes)"

_^tab^_

![Color image not adapted for dark mode](pic/iphone-home-light.png?srcset=@2x,@3x#padding)

![Color image adapted for dark mode: replaced with specified image](pic/iphone-home-light.png?darksrc=pic/iphone-home-dark.png#padding)

![Color image adapted for dark mode: replaced with specified multi-resolution image set](pic/iphone-home-light.png?darksrc=pic/iphone-home-dark.png&srcset=@2x,@3x&darksrcset=@2x,@3x#padding)

## Image Silhouette

*Markdown Fans`Q`*「**Hope images in documents can automatically follow the document theme color or text color, without needing to recreate multiple versions of image resources**」

*VLOOK`A`*_~T2~_ Can target transparent background png or svg images, displaying their outlines with specified colors.

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

> In the "image address", add VLOOK™ standardized URL parameters to achieve:
>
> - URL parameter: `fill=color identifier`

*==Image Silhouette URL Parameters (fill) Identifiers and Descriptions==*

| Color Identifier | Description |
| :----------: | ------------------------------------------------------------ |
| text | Replace with the color of the paragraph text (automatically adapts to Dark Mode and link styles) |
| Color Code | Replace with specified color from [Preset Color Code](#Preset Color Code), e.g.: `Rd` `Ye` |

> [!NOTE]
>
> Due to Safari browser kernel compatibility issues, the preview during editing in Typora will not show the final effect. The exported HTML will display normally when accessed using [recommended browsers](index-en.md#Upgrade and Compatibility).

###### Image Silhouette Mixed Layout Example

1. Different content using `text` color identifier will automatically adapt:
   - Adapt to ==normal text== color: ![Markdown](pic/markdown-mark-solid.svg?fill=text#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=text#icon) is a text markup language specifically for web writing
   - Adapt to ==link text== color: What is [![Markdown](pic/markdown-mark-solid.svg?fill=text#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=text#icon)](https://en.wikipedia.org/wiki/Markdown)?
   - Adapt to ==button link== color: [<kbd>![](pic/markdown-mark-solid.svg?fill=text) Markdown ![](pic/markdown-mark-solid.png?fill=text)</kbd>](https://en.wikipedia.org/wiki/Markdown) *[<kbd>![](pic/markdown-mark-solid.svg?fill=text) Markdown ![](pic/markdown-mark-solid.png?fill=text)</kbd>](https://en.wikipedia.org/wiki/Markdown)*
   - Adapt to [blockquote (colored)](#Blockquote-Coloring), [GitHub Style Alert](guide2-en.md#GitHub-Style-Alert) colors

2. Using specified [Preset Color Code](#Preset Color Code):

*==Image Silhouette Specified as Preset Color Code Example==*

| Color | Color Code | Image Silhouette Effect Example |
| :---------------: | :------: | ------------------------------------------------------------ |
| Wine Red | Wn_~Wn~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=wn#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=Wn#icon) icon replaced with specified color |
| Red | Rd_~Rd~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Rd#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=Rd#icon) icon replaced with specified color |
| Orange | Og_~Og~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Og#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=Og#icon) icon replaced with specified color |
| Yellow | Ye_~Ye~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Ye#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=ye#icon) icon replaced with specified color |
| Lime Green | Lm_~Lm~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Lm#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=lm#icon) icon replaced with specified color |
| Green | Gn_~Gn~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Gn#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=gn#icon) icon replaced with specified color |
| Mineral Green | Mn_~Mn~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Mn#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=mn#icon) icon replaced with specified color |
| Olive Green | Ol_~Ol~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Ol#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=ol#icon) icon replaced with specified color |
| Aqua Green | Aq_~Aq~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Aq#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=aq#icon) icon replaced with specified color |
| Cyan | Cy_~Cy~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Cy#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=cy#icon) icon replaced with specified color |
| Blue | Bu_~Bu~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Bu#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=bu#icon) icon replaced with specified color |
| Sea Blue | Se_~Se~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Se#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=se#icon) icon replaced with specified color |
| Lavender Purple | La_~La~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=La#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=la#icon) icon replaced with specified color |
| Vine Purple | Vn_~Vn~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Vn#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=vn#icon) icon replaced with specified color |
| Purple | Pu_~Pu~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Pu#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=pu#icon) icon replaced with specified color |
| Rose Pink | Ro_~Ro~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Ro#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=ro#icon) icon replaced with specified color |
| Pink | Pk_~Pk~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Pk#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=pk#icon) icon replaced with specified color |
| Gold | Gd_~Gd~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Gd#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=gd#icon) icon replaced with specified color |
| Brown | Bn_~Bn~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Bn#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=bn#icon) icon replaced with specified color |
| Gray | Gy_~Gy~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Gy#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=gy#icon) icon replaced with specified color |
| Black | Bk_~Bk~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=Bk#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=bk#icon) icon replaced with specified color |
| Theme Primary Color | T1_~T1~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=T1#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=t1#icon) icon replaced with specified color |
| Theme Secondary Color | T2_~T2~_ | ![Markdown](pic/markdown-mark-solid.svg?fill=T2#icon) Markdown ![Markdown](pic/markdown-mark-solid.png?fill=t2#icon) icon replaced with specified color |

###### Blockquote Coloring and Title Example

> **This is ![Markdown](pic/markdown-mark.svg?fill=text#icon) Markdown's Level 6 Heading**
>
> Here is the main content.
>
> _~Pk~_

> [!IMPORTANT]
>
> Due to browser cross-origin security policies, for documents using this feature with SVG format images, it is recommended to publish them to an HTTP server, with the image path and HTML path under the same domain (i.e., no cross-origin), e.g.: HTML document published at `http://<DomainA>/index.html`
>
> - ✅✅✅ Correct image address example: `http://<DomainA>/img/xxx.svg`
> - ❌❌❌ Incorrect image address example: `http://<DomainBBB>/img/xxx.svg`
>
> > ###### Different Opening Methods and Browser Instructions for SVG Images Enabling "Image Silhouette"
> >
> > *==Image Address Instructions for Enabling "Image Silhouette"==*
> >
> > | Browser | Directly Open Local HTML File | == | Access HTML via HTTP | == |
> > | :-----------: | :--------------------------: | :--------: | :----------------------------------------------------------: | :--------: |
> > | : | []Relative Path | []URL Path | []Relative Path | []URL Path |
> > | Chrome / Edge | | | Y | Y |
> > | Firefox | Y | | Y | Y |
> > | Safari | Y<br>（** Must specify default image host） | Y | Y | Y |
> > | / | == | == | *⚠️`Note`*_~Rd!~_ **Image path and HTML path "domain" must be consistent** | == |
> >
> > ** To achieve color replacement for image paths that are relative paths (actually deployed on a specified server or image host), you need to specify the default image host address through [Preset Options](guide3-en.md#Plugin-Preset-Options) `vlook-image-host`.
>

## ~~GIF Playback Control~~

Using online videos can be large in size and vulnerable to attacks. Often converted to GIF for suitability, but they automatically play causing unnecessary traffic.

Achieve more friendly interaction and save traffic by implementing click-to-play similar to videos.

In addition to GIF, it's recommended to include a cover image.

Then add `#gif` after the image address, clicking will play the `.gif` file with the same name.

`![Title](xxx.png#gif)`

## ~~Image Comparison~~

> ###### COMMING SOON...
> 
> ![VLOOK™ - Color Card Preset Color Code](pic/vlook-color-card-light.png#logo)
> 
> ---
> 
> ![VLOOK™ - Color Card Preset Color Code](pic/vlook-color-card-dark.png#logo)
> 
> _~Gy!~_

## ~~Image Gallery~~

> ###### COMMING SOON...
> 
> ![](pic/vlook-screenshot-A00.png#logo)
> 
> ![](pic/vlook-screenshot-A01.png#logo)
> 
> ![](pic/vlook-screenshot-A02.png#logo)
> 
> _~Gy!~_

## Image Alignment

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

- Image alignment (left, center) is specified by the selected VLOOK™ theme, support custom alignment through [Custom Theme Service](vip-en.md);
- Includes cases where there's only one image in a paragraph, images with links, etc., but excludes [icon layout](#Image-Display-Layout) images.

## Image Caption & Auto-numbering

<u>About image captions and auto-numbering</u>

[<kbd>Related content see here ❯❯</kbd>](guide2-en.md#°Caption)

---

For feedback: [![Feedback via Email](pic/feedback-via-email.svg?darksrc=invert#icon)](mailto:67870144@qq.com?subject=Feedback%20about%20VLOOK™&body=Hi, "Feedback via Email")  [![Feedback via QQ](pic/feedback-via-qq.svg?darksrc=invert#icon)](https://qm.qq.com/q/O0tNC6WBWe "QQ Group (805502564)")  [![Feedback via Telegram](pic/feedback-via-telegram.svg#icon)](https://t.me/vlook_markdown "Join Telegram Channel")

# °List

## List Auto-numbering & Coloring

In addition to the previously mentioned [List Columns](guide2-en.md#List-Columns), the following enhancements are provided:

1. Unified processing of bullet symbols for ordered and unordered lists, applying theme colors;
2. Editing focus and mouse hover in exported HTML both support highlighting current list symbols;
3. Support personalized symbol styles for first-level ordered lists :
   1. Temporarily not applicable to ordered lists within [GitHub Style Alert](guide2-en.md#GitHub-Style-Alert);
   2. Ordered lists within quotes need preceding content (like blank lines, subtitles, etc.).

> [!TIP]
>
> There are currently 7 available styles for first-level ordered lists. For details, see [Custom Theme ❯❯](vip-en.md)



> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

---

> **Auto-numbering for Ordered Lists in Blockquotes**
> 
> 1. Auto-numbering styles for ordered lists:
>    1. Force-set symbols for each level, applying theme colors.
>       1. Third-level ordered list
>          1. Fourth-level ordered list
>             1. Fifth-level ordered list
> 
>                1. Sixth-level ordered list
>
> > ###### Top 20 Ordered List Styles
> > 
> > 1. Top 9 styles
> > 2. Top 9 styles
> > 3. Top 9 styles
> > 4. Top 9 styles
> > 5. Top 9 styles
> > 6. Top 9 styles
> > 7. Top 9 styles
> > 8. Top 9 styles
> > 9. Top 9 styles. If content is too long it will auto-wrap, check the indentation after wrapping.
> > 10. Top 10-19 styles. If content is too long it will auto-wrap, check the indentation after wrapping.
> > 11. Top 10-19 styles
> > 12. Top 10-19 styles
> > 13. Top 10-19 styles
> > 14. Top 10-19 styles
> > 15. Top 10-19 styles
> > 16. Top 10-19 styles
> > 17. Top 10-19 styles
> > 18. Top 10-19 styles
> > 19. Top 10-19 styles
> > 20. Top 20 styles
> 
> _~T2~_

> **Auto-numbering for Unordered Lists in Blockquotes**
> 
> - Auto-numbering styles for unordered lists:
>   - Force-set symbols for each level, applying theme colors.
>     - Third-level unordered list
>       - Fourth-level unordered list
>         - Fifth-level unordered list
>           - Sixth-level unordered list
> 
> _~Gd!~_

1. This is auto-numbering style for ordered lists in normal text:
   1. Force-set symbols for each level, applying theme colors.
      1. Third-level ordered list
         1. Fourth-level ordered list
            1. Fifth-level ordered list
               1. Sixth-level ordered list

- This is auto-numbering style for unordered lists in normal text:
  - Force-set symbols for each level, applying theme colors.
    - Third-level unordered list
      - Fourth-level unordered list

> [!TIP]
> 
> The above are partial examples of list styles. For more examples with blockquote coloring, see here [❯❯](#Blockquote-Coloring)

## List Columns

<u>About column typesetting for lists</u>

[<kbd>Related content see here ❯❯</kbd>](guide2-en.md#List-Columns)

## Task List Style

*Markdown Fans`Q`*「**The default generated task list style is the browser's standard checkbox style, inconsistent with the theme and enhanced typesetting effects～**」

*VLOOK`A`*_~T2~_ VLOOK™ has made multiple style and detail adaptations for this situation, making the overall to detailed visuals more harmonious and consistent.

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

**Overall task progress:** **==?==**

- [ ] **1. Analyze target market demand** **==?==**
  - [ ] Survey target customer groups **==?==**
    - [x] Develop questionnaire or face-to-face interview plan
    - [ ] Collect customer needs and preference information for products/services
  - [ ] Research competitors **==?==**
    - [ ] Analyze competitor products, pricing strategies and market share
    - [ ] Identify competitor strengths/weaknesses and compare with own
- [ ] **2. Collect market data** **==?==**
  - [ ] Review industry reports and data **==?==**
    - [x] Review industry reports and statistics published by industry associations
    - [ ] Collect information on industry trends and development forecasts
  - [x] Analyze market trends **==?==**
    - [x] Process market data through analysis tools/software
    - [x] Identify and explain market trends to guide project decisions

> [!TIP]
> 
> The above are examples of task list styles in main text. For more examples with blockquote coloring, see here [❯❯](#Blockquote-Coloring)

---

For feedback: [![Feedback via Email](pic/feedback-via-email.svg?darksrc=invert#icon)](mailto:67870144@qq.com?subject=Feedback%20about%20VLOOK™&body=Hi, "Feedback via Email")  [![Feedback via QQ](pic/feedback-via-qq.svg?darksrc=invert#icon)](https://qm.qq.com/q/O0tNC6WBWe "QQ Group (805502564)")  [![Feedback via Telegram](pic/feedback-via-telegram.svg#icon)](https://t.me/vlook_markdown "Join Telegram Channel")

# °Blockquotes

## Blockquote Subtitle

*Markdown Fans`Q`*「**Want to add a subtitle within a blockquote, but using hierarchical headings directly isn't quite appropriate**」

*VLOOK`A`*_~T2~_ Generally the first paragraph in a blockquote serves as the subtitle, so setting the entire paragraph content as bold or highlighted automatically renders as a "blockquote subtitle" style!

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

_^tab^_

> **Syntax**
> 
> Set the first line in a blockquote as "**bold**" or "==highlight==".
> 
> Also supports adding "[icon layout](#Image-Display-Layout)" images before the subtitle in a standalone line for richer typesetting options～

> [!TIP]
> 
> If you need to bold the entire first/second line within a blockquote but don't want to activate the "subtitle" style, just add a "space" after the bold format `**`.

*==Blockquote Subtitle Example==*

```markdown
> **Here is the subtitle for this blockquote**
> ---
> xxxxx

> ==Here is the subtitle for this blockquote==
> ---
> xxxxx
```

###### Example Effect Below:

---

> **Bold-Set Blockquote Subtitle**
>
> Other paragraph content 1 within this blockquote
>
> Other paragraph content 2 within this blockquote
>

> ==Highlight-Set Blockquote Subtitle==
>
> Other paragraph content 1 within this blockquote
>
> Other paragraph content 2 within this blockquote
>
> For more subtitle styles, see Blockquote Coloring [❯❯](#Blockquote-Coloring)

## Blockquote Columns

<u>About blockquote column typesetting</u>

[<kbd>Relevant content see here ❯❯</kbd>](guide2-en.md#Blockquote-Columns)

## Blockquote Coloring

*Markdown Fans`Q`*「**Hope to create banners or boards in Markdown documents to write important things～**」

*VLOOK`A`*_~T2~_ VLOOK™'s [Preset Color Code](#Preset Color Code) come into play again, same formula, same super usability! Meets practical multi-color "blockquote" typesetting needs!

> **Applicable Scope ••• *`Editing`× Not Supported*_~Gy~_  *`Export HTML`✓ Supported*_~Gn~_**

_^tab^_

> **Syntax**
>
> Add corresponding color code `_~Color Code~_` in a **standalone line** within the blockquote (recommended in the last line), e.g.: `_~Rd~_`
>
> > Where: `Color Code` specifies the [Preset Color Code](#Preset Color Code) used for this blockquote. When correctly recognized, a blockquote coloring marker will appear before the color code.
>
> - Default is "**Outline**" style;
> - To specify as "**Color Block**" style, use "**Emphasized**" predefined color codes (add English exclamation mark "**!**" after `Color Code`, e.g.: `_~Rd!~_`).

> [!TIP]
>
> All unspecified ordinary blockquotes (normal paragraphs, excluding blockquotes within lists or other blockquotes) will be automatically converted to blockquotes with color code `T1!`.
>
> To modify the default color code or disable automatic conversion, specify through "[Plugin Tuning Parameters](guide3-en.md#Plugin-Tuning-Parameters)" `quote`.

###### Tag Example in Main Text

> **![Wine](pic/qico-red.svg?fill=text&darksrc=invert#icon) Normal Blockquote**
>
> [<kbd>Main Button ![](pic/icon-more.svg?fill=text)</kbd>](guide2-en.md#Button-Links) *[<kbd>Secondary Button ![](pic/icon-more.svg?fill=text)</kbd>](guide2-en.md#Button-Links)*
>
> > ###### More Information
> >
> > - [x] This is a task list item
> >
> > - This is an unordered list item
> >
> > 1. This is an ordered list item

---

> **![Wine](pic/qico-red.svg?fill=text&darksrc=invert#icon) Blockquote Coloring**
>
> ==Color Code==  `Wn`　Learn[Color Code ℹ️](#Preset Color Code)　[<kbd>Main Button ![](pic/icon-more.svg?fill=text)</kbd>](guide2-en.md#Button-Links) *[<kbd>Secondary Button ![](pic/icon-more.png?fill=text)</kbd>](guide2-en.md#Button-Links)*
>
> > ###### More Information
> >
> > - [x] This is a task list item
> >
> > - This is an unordered list item
> >
> > 1. This is an ordered list item
>
> _~Wn~_

[... Additional blockquote coloring examples continue in same pattern ...]

## Blockquote Folding

*Markdown Fans`Q`*「**When writing Markdown documents, for some long blockquote content, hope it can exist in folded form by default, and click to open when needed.**」

*VLOOK`A`*_~T2~_ By extending the writing method of Markdown blockquotes `> `, achieves dynamic folding/unfolding of blockquote content!

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

> Syntax: `> ###### title`, i.e., set the first line content of normal blockquote syntax as level 6 heading, which serves as the title displayed when folded
>
> Where,
>
> `title`: The title corresponding to the folded content, separated from the folding trigger by "English space". When correctly recognized, a folding marker will appear before the level 6 heading.
>
> **After using this syntax, all content within its blockquote becomes the folded part**

###### Practical Application Example

> ###### What is Syllogism?
>
> Syllogism is a simple deductive reasoning in logic. It contains:
>
> - *`Major Premise`* A general principle
> - *`Minor Premise`* A specific statement subordinate to the major premise
> - *`Conclusion`*_~T2!~_ The derived specialized statement conforms to the general principle's conclusion

> > ###### What is the MECE Principle?
> >
> > MECE^[[me_see]]^ analysis stands for Mutually Exclusive Collectively Exhaustive, meaning "no overlaps, no gaps" in Chinese.
> >
> 
> Here are five classification methods of MECE:
> 
> > ###### Dichotomy
> >
> > Dichotomy is common in daily life, essentially dividing things into A and non-A parts, such as "day/night", "male/female", "domestic/foreign", "internal/external", etc.
> 
> > ###### Process Method
> >
> > The process method breaks down procedures according to their timeline, processes, or sequences.
> >
> > > **Example** 
> > >
> > > The production of cloisonné can be divided into seven steps: base making, wire inlaying, firing, enamel filling, enamel firing, polishing, and gilding.
> 
> > ###### Element Method
> >
> > The element method is mainly used when things consist of certain components, dividing a whole into different parts; however, **when decomposing elements, maintain dimensional consistency** to avoid overlaps or gaps.
> >
> > > **Example** 
> > >
> > > A library can be divided by floor dimension: first floor, second floor, third floor; or by functional areas: information service area, collection area, reading area, public activity area, office area; but cannot mix floor and functional area dimensions, otherwise it violates the MECE principle.
> 
> > ###### Formula Method
> >
> > The formula method classifies elements according to designed formulas. If the formula holds, then the element classification complies with MECE.
> >
> > For example: `GMV = Traffic × Average Order Value`
> 
> > ###### Matrix Method
> >
> > The matrix method classifies or divides things using a two-dimensional matrix, such as the common urgent/important classification in time management: urgent and important, urgent but not important, not urgent but important, not urgent nor important.

*==Example Markdown Source Content==*

```markdown
> ###### What is Syllogism?
>
> Syllogism is a simple deductive reasoning in logic. It contains:
> 
> - **Major Premise**: A general principle
> - **Minor Premise**: A specific statement subordinate to the major premise
> - **Conclusion**: The specific conclusion derived from the premises that conforms to the general principle
```

## Blockquote Typesetting Subdivision

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

###### Example of Nested Blockquotes in Blockquotes

---

> The style of normal blockquotes nested within blockquotes will automatically adjust to a "minimalist" style, as follows:
>
> > This is a normal blockquote nested within a blockquote

> The style of normal blockquotes nested within blockquotes will automatically adjust to a "minimalist" style, as follows:
>
> > ###### This is a collapsible blockquote nested within a blockquote
> >
> > Collapsed content

###### Example of Column Blockquotes Nested in Blockquotes

> The style of "blockquote columns" nested within blockquotes will automatically adjust to a "prominent" style, as follows:
>
> ---
>
> > This is "blockquote column" 1 nested within a blockquote
>
> > This is "blockquote column" 2 nested within a blockquote

###### Example of Blockquotes Nested in Lists

- Normal blockquotes nested within unordered or ordered lists will adjust to a "self-adapting width" style and won't be converted by default (see `quote` in [Plugin Tuning Parameters](guide3-en.md#Plugin Tuning Parameters)), as follows:

  > ![Theme2](pic/qico-theme2.svg?fill=text&darksrc=invert#icon) Normal Blockquote
  >
  > This is content of a normal blockquote

- "Blockquote coloring" nested within unordered or ordered lists will adjust to a "self-adapting width" style, as follows:

  > ###### ![Theme2](pic/qico-theme2.svg?fill=text&darksrc=invert#icon) Blockquote Coloring
  >
  > This is a *blockquote coloring`theme secondary color`*_~T2~_, ==color code== `T2`　Learn about[color codesℹ️](#Preset Color Code) 
  >
  > _~T2~_

---

For feedback: [![Feedback via Email](pic/feedback-via-email.svg?darksrc=invert#icon)](mailto:67870144@qq.com?subject=Feedback%20about%20VLOOK™&body=Hi, "Feedback via Email")  [![Feedback via QQ](pic/feedback-via-qq.svg?darksrc=invert#icon)](https://qm.qq.com/q/O0tNC6WBWe "QQ Group (805502564)")  [![Feedback via Telegram](pic/feedback-via-telegram.svg#icon)](https://t.me/vlook_markdown "Join Telegram Channel")

# °Chapter Headings



## Heading Style？？

==VLOOK™'s [Built-in Themes](guide3-en.md#Template-Themes) provide rich choices for document headings, along with various automatic numbering formats？？ .==

<u>For more personalized heading styles (e.g., colors, gradients, borders, padding, etc.) or custom automatic numbering formats, you can subscribe to ==Custom Theme Services== .</u>

**[<kbd>Explore More About Custom Themes</kbd>](vip-en.md)**

> [!NOTE]
>
> When using a theme with gradient-colored headings, emojis in the heading will also be force-rendered with the gradient.
>
> To fix this, simply make the emoji "**bold**".

## Automatic Heading Numbering

*Markdown Fans`Q`*「**Hope to customize automatic heading numbering in documents to adapt to specific document styles and heading content organization**」

*VLOOK`A`*_~T2~_ VLOOK™ provides very practical and personalized heading numbering format options that can easily meet the personalized requirements of different documents for heading numbering formats.

> **Applicable Scope ••• *`Editing`✓ Supported*_~Gn~_  *`Export HTML`✓ Supported*_~Gn~_**

After using the VLOOK™ plugin, it supports automatic numbering of chapter headings in documents by default. The default automatic numbering format is Arabic numerals, such as `1. Chapter Heading` `3.2.5 Chapter Heading`.

- All VLOOK™ themes automatically apply hierarchical numbering to `Level 1 ~ 5` headings;
- Because `Level 6` headings are used in VLOOK™ for [Front and Back Covers](guide2-en.md#°Cover & Back Cover), paragraph subheadings, etc., they are not within the automatic numbering range.

You can specify through "[Plugin Preset Options](guide3-en.md#Plugin-Preset-Options)" `vlook-header-autonum` to take effect after exporting HTML. The formatting examples are as follows:

*==Custom Heading Automatic Numbering Format Examples==*

```yaml
---
vlook-header-autonum: Level1{{Prefix#Format#Suffix}},Level2{{Prefix#Format#Suffix}},...,Level5{{Prefix#Format#Suffix}}
---
```

_^tab^_

> [!TIP]
>
> If the VLOOK theme does not include automatic numbering styles, this parameter can also be used to forcibly specify enabling automatic numbering and corresponding formats after exporting HTML.

> [!NOTE]
>
> For more information about setting plugin preset options through YAML Front Matter, see [Plugin Preset Options](guide3-en.md#Plugin-Preset-Options)

*==Options Explanation for Custom Title Auto-numbering Format==*

| **Numbering Option** |         Values         | Description                                                  | Option Reference                            | Effect Preview                              |
| :------------------: | :--------------------: | ------------------------------------------------------------ | ------------------------------------------- | ------------------------------------------- |
|       Level          |     `h1` ～ `h5`       | Represents level 1 to level 5 headings                       | `h3{{###}}`                                 | 1.2.3 xxxxx                                 |
|       Prefix         |     Any text content   | Such as: 第, Chapter                                         | `h1{{Chapter ###.}}`                        | Chapter 5. xxxxx                            |
|       Format         |        `none`          | Disable auto-numbering                                       | `h2{{#none#}}`                              | xxxxx                                       |
|         :            |         `#`            | Arabic numerals. E.g.: 1, 2, 3, 4, 5                        | `h2{{Chapter ###}}`                         | Chapter 3.2 xxxxx                           |
|         :            |         `zh`           | Chinese numerals. E.g.: 一、二、三、四、五<br>*`Note`*_~Rd~_ **Effective for `h1` only** | `h1{{第#zh#章}}`                            | 第一章 xxxxx                                |
|         :            |         `ZH`           | Chinese uppercase numerals. E.g.: 壹、贰、叁、肆、伍<br>*`Note`*_~Rd~_ **Effective for `h1` only** | `h1{{第 #ZH# 回}}`                          | 第 伍 回 xxxxx                              |
|         :            |       `alpha`          | Lowercase English letters. E.g.: a, b, c, d, E<br>*`Note`*_~Rd~_ **Effective for `h1` or `-min` only** | `h2{{#alpha#}}`                             | a xxxxx                                     |
|         :            |       `ALPHA`          | Uppercase English letters. E.g.: A, B, C, D, E<br>*`Note`*_~Rd~_ **Effective for `h1` or `-min` only** | `h2{{#ALPHA#}}`                             | A xxxxx                                     |
|         :            |       `roman`          | Lowercase Roman numerals. E.g.: i, ii, iii, iv, v<br>*`Note`*_~Rd~_ **Effective for `h1` or `-min` only** | `h3{{#roman# •}}`                           | i • xxxxx                                   |
|         :            |       `ROMAN`          | Uppercase Roman numerals. E.g.: I, II, III, IV, V<br>*`Note`*_~Rd~_ **Effective for `h1` or `-min` only** | `h3{{#ROMAN#}`                              | IV • xxxxx                                  |
|     Extension        | `00`<br>`000`<br>...  | Fixed-length placeholder, left-padded with zeros if insufficient | `h1{{Chapter #00## /}}`                     | Chapter 002 / xxxxx                         |
|         :            |        `-min`          | Display numbering in single-level mode<br>*`Note`*_~Rd~_ **Mutually exclusive with `-sup`** | `h3{{步骤 #0#-min# -}}`                     | 步骤 01 - xxxxx                             |
|         :            |        `-sup`          | Display numbering in dual-level mode<br>*`Note`*_~Rd~_ **Mutually exclusive with `-min`** | `h2{{附录 #ALPHA-min#.}},h3{{#00#-sup# -}}` | Level 2: 附录 A - xxx<br>Level 3: 附录 A.01 - xxx |
|       Suffix         |     Any text content   | Such as: 章, .                                               | `h1{{#zh#、}}`                              | 1）xxxxx                                    |

<u>For more personalized heading styles (e.g., colors, gradients, borders, padding, etc.) or custom automatic numbering formats, you can subscribe to ==Custom Theme Services== .</u>

**[<kbd>Explore More About Custom Themes</kbd>](vip-en.md)**

## This is a level 2 heading example

(Content)

### This is a level 3 heading example

(Content)

#### This is a level 4 heading example

(Content)

##### This is a level 5 heading example

(Content)

###### This is a level 6 heading example

(Content)



